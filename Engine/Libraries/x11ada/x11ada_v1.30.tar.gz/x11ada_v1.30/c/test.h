/* $Source: /home/harp/1/proto/monoBANK/xbind/test.h,v $ */
/* $Revision: 1.2 $ $Date: 95/04/14 16:34:33 $ $Author: mg $ */

#define __STDC__ 1
#define XTSTRINGDEFINES 1
#define XMSTRINGDEFINES 1

/* 
 * The name mgconst is used for "const" declarations added to the *.h
 * files by mg.  This name was used in case some of the changes have
 * to be backed out later.
 */
#define mgconst const

/* Xlib */
#include "Xlib.h"
#include "Xlibnet.h"

/* Xt */
#include "Intrinsic.h"
#include "Composite.h"
#include "Constraint.h"
#include "Core.h"
#include "Object.h"
#include "RectObj.h"
#include "Shell.h"
#include "StringDefs.h"
#include "Vendor.h"
#include "fd.h"

/* Motif */
#include "XmAll.h"
