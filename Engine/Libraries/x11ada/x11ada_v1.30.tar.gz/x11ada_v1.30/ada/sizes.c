/* $Source: /home/harp/1/proto/monoBANK/xbind/sizes.c,v $ */
/* $Revision: 1.1 $ $Date: 95/06/21 13:05:55 $ $Author: mg $ */
main() {
    printf("char %d\n", sizeof(char));
    printf("short %d\n", sizeof(short));
    printf("int %d\n", sizeof(int));
    printf("long %d\n", sizeof(long));
    printf("float %d\n", sizeof(float));
    printf("double %d\n", sizeof(double));
    printf("char * %d\n", sizeof(char *));
}
