/* file: pconfig.h.in
   LynxOS version
 */
#define _POSIX_C_SOURCE 199506L
#define _REENTRANT
#define _POSIX_C_SIGNALS_C
#define _BSD_SOURCE
#include <semaphore.h>
#include <arpa/inet.h>
