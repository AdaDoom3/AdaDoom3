This directory contains the sources of SQLite (so called amalgation)  as
distributed at the download page: 

   http://www.sqlite.org/download.html

The  sources  are  compiled  and linked with, when SQLite is used as the
persistence layer. 