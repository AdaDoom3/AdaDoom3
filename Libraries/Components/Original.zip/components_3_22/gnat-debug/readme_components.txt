This  directory  contains  implementations of the packages of the simple
components project. See the documentation: 

   http://www.dmitry-kazakov.de/ada/components.htm
   
The  implementations  are  used  for debugging reference counted objects
when used with GNAT Ada. Note that the implementation are GNAT-specific. 

The   simple   component   project   file   automatically   chooses   an
implementation according to the project switches. 
