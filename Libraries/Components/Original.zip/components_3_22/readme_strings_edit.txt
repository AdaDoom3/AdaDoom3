This  directory  contains sources of strings edit software project. See

   http://www.dmitry-kazakov.de/ada/strings_edit.htm 

The subdirectory tests_strings_edit contains self-tests.
