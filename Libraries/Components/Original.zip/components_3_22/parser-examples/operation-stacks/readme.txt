This directory contains operation stack example program. To build  it
using GNAT you can go as follows:

gnatmake -I../../ test_operation_stack.adb
