This  directory  contains  small calculator example program. To build it
using GNAT you can go as follows: 

gnatmake -I../../ console_calculator.adb
