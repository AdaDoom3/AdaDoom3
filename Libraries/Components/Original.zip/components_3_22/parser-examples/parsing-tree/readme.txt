This directory contains a full Ada 95 expression parser. To build a test
program with GNAT you can go as follows:  

gnatmake -I../../ test_ada_parser.adb

This test program parses  various  Ada  95  expressions,  most  of  them
borrowed from Ada Reference Manual. 
