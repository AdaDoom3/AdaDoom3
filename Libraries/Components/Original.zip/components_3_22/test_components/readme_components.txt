This  directory  contains  various  tests  for  simple  components.  For
description of the tests and building instructions see:

   http://www.dmitry-kazakov.de/ada/components.htm#tests

Additional software might be required for the tests using GNADE or APQ.
