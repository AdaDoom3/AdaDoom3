This  directory  contains  implementations of the packages of the simple
components project. See the documentation: 

   http://www.dmitry-kazakov.de/ada/components.htm
   
The implementations are used for applications that deploy single task to
access reference counted objects. 

The   simple   component   project   file   automatically   chooses   an
implementation according to the project switches. When used with another
compiler or else compiled manually, the files from this directory are to
supersede the corresponding files in the parent directory.
