This  directory  contains  packages of the simple components project.
See the documentation:

   http://www.dmitry-kazakov.de/ada/components.htm
   
The subdirectory test_components contains self-tests.
