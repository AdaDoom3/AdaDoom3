This directory contains various tables tests. To build  them  with  GNAT
Ada compiler use the following command line:  

gnatmake -I../ test_tables.adb
