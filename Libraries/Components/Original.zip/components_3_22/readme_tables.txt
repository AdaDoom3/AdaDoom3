This  directory  contains packages of the tables project as described in
the documentation. See 

   http://www.dmitry-kazakov.de/ada/tables.htm

The subdirectory test_tables contains self-tests.
