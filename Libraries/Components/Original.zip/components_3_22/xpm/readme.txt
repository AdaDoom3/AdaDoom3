This directory contains sources of generic xpm parser. See 

   http://www.dmitry-kazakov.de/ada/components.htm#Parsers.Generic_Source.XPM
