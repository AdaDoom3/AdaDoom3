ADA_PROJECT_PATH=$LACE/1-base/lace/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/1-base/math/library:$ADA_PROJECT_PATH


ADA_PROJECT_PATH=$LACE/2-low/physics/bullet/contrib/bullet-2.79/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/physics/bullet/library:$ADA_PROJECT_PATH

ADA_PROJECT_PATH=$LACE/2-low/physics/box2d/contrib/Box2D/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/physics/box2d/library:$ADA_PROJECT_PATH

ADA_PROJECT_PATH=$LACE/2-low/physics/impact/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/physics/vox/library:$ADA_PROJECT_PATH

ADA_PROJECT_PATH=$LACE/2-low/physics/interface/library:$ADA_PROJECT_PATH


ADA_PROJECT_PATH=$LACE/2-low/graphics/opengl/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/graphics/opengl/private/gid:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/graphics/opengl/private/collada/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/graphics/opengl/private/thin/egl/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/graphics/opengl/private/thin/gl/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/graphics/opengl/private/thin/glu/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/2-low/graphics/opengl/private/thin/glx/library:$ADA_PROJECT_PATH

ADA_PROJECT_PATH=$LACE/2-low/xml/library:$ADA_PROJECT_PATH


ADA_PROJECT_PATH=$LACE/4-high/mmi/library:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/4-high/mmi/library/xcb:$ADA_PROJECT_PATH
ADA_PROJECT_PATH=$LACE/4-high/mmi/source/private/xcb/library:$ADA_PROJECT_PATH


export ADA_PROJECT_PATH
