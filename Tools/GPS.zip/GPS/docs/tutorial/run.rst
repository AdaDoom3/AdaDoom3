***
Run
***

It is now time to run the application: select the menu `Build->Run->sdc`, which
will open a dialog window.  In the text input field (selected by default),
press the right arrow key and then insert `input.txt`: this is the name of a
text file that will be passed as argument to the *sdc* program.

The text input should now read: `%E input.txt` and the full command that will
be executed is displayed underneath: `.../gps/tutorial/obj/sdc input.txt`

Now click on `Execute`: a new window titled `Run: sdc` is created at the bottom
of the main window where the sdc application runs and displays an unexpected
internal error: this is a good opportunity to use the integrated debugger.

Close the execution window by clicking on the x icon on the top right corner of
this window.

