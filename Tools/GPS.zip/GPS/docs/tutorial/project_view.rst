***********************
Project View (entities)
***********************

Click on the `[+]` sign (or triangle) to open :file:`tokens.ads` entities.
When you click on a file in the project view, you get
language sensitive information about the file, such as
`packages`, `subprograms`, `tasks`, ... for `Ada`.

Open the `subprogram` category, click on `Process`: this
will open :file:`tokens.ads` and move the cursor on the first line
corresponding to the procedure `Process`.

Similarly, click on `Next`, and move your mouse on `Next`
in the source editor.

