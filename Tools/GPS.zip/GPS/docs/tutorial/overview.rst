*******************************
Quick overview of the GPS areas
*******************************

Having launched GPS, you should now have access to a main window composed of
several areas:

* a menu bar at the top
* a tool bar under the menu bar
* a scenario view under the tool bar, on the left side
* a project view under the scenario view, on the left side
* a working area on the right of the project view
* a messages window under the working area

