#!/bin/bash

. `dirname $0`/../../scripts/CONFIG.sh

./driver.sh "$@"
