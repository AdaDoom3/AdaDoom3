# Called at DarkRadiant startup

print('init.py executed')