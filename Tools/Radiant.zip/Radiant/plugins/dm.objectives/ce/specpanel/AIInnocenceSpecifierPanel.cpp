#include "AIInnocenceSpecifierPanel.h"

namespace objectives {

namespace ce {

// Reg helper
AIInnocenceSpecifierPanel::RegHelper AIInnocenceSpecifierPanel::_regHelper;

} // namespace ce

} // namespace objectives
