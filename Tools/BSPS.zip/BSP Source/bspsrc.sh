#!/bin/sh
java -cp bspsrc.jar info.ata4.bspsrc.gui.BspSourceFrame $*
