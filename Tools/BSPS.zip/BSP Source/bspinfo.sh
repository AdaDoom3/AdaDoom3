#!/bin/sh
java -cp bspsrc.jar info.ata4.bspinfo.gui.BspInfoFrame $*
